// This script will be injected into Emoji Studio pages to establish communication
(function() {
  console.log('[Emoji Studio Extension] Inject script loaded on:', window.location.href);
  
  // Check if we're on the dashboard with extension parameter
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('extension') === 'true' && window.location.pathname.includes('dashboard')) {
    console.log('[Emoji Studio Extension] Checking for pending data in chrome.storage');
    
    // Check chrome.storage for pending data
    chrome.storage.local.get(['pendingExtensionData'], (result) => {
      console.log('[Emoji Studio Extension] Chrome storage result:', result);
      if (result.pendingExtensionData) {
        console.log('[Emoji Studio Extension] Found pending data:', result.pendingExtensionData);
        
        // Small delay to ensure the page is ready
        setTimeout(() => {
          // Send data to the page
          window.postMessage({
            type: 'EMOJI_STUDIO_DATA',
            data: result.pendingExtensionData
          }, '*');
          
          console.log('[Emoji Studio Extension] Data posted to window');
        }, 500);
        
        // Clear the pending data
        chrome.storage.local.remove(['pendingExtensionData']);
        console.log('[Emoji Studio Extension] Pending data cleared from storage');
      } else {
        console.log('[Emoji Studio Extension] No pending data found in chrome.storage');
      }
    });
  }
  
  // Listen for messages from the extension
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[Emoji Studio Extension] Received message:', request.type, request.data);
    
    if (request.type === 'EMOJI_STUDIO_DATA') {
      // Forward the data to the page
      console.log('[Emoji Studio Extension] Forwarding data to window:', request.data);
      window.postMessage({
        type: 'EMOJI_STUDIO_DATA',
        data: request.data
      }, '*');
      
      console.log('[Emoji Studio Extension] Data forwarded to page');
      sendResponse({ success: true });
    }
    return true; // Keep message channel open
  });
  
  // Also listen for window messages to confirm they're being received
  window.addEventListener('message', (event) => {
    console.log('[Emoji Studio Extension] Window message received:', event.data.type);
    if (event.data.type === 'EMOJI_STUDIO_DATA') {
      console.log('[Emoji Studio Extension] Window received EMOJI_STUDIO_DATA message:', event.data);
    }
  });
  
  // Notify the extension that we're ready
  window.postMessage({ type: 'EMOJI_STUDIO_READY' }, '*');
  console.log('[Emoji Studio Extension] Ready message sent');
})();