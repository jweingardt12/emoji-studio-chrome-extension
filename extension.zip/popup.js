document.addEventListener('DOMContentLoaded', async () => {
  const statusIndicator = document.getElementById('statusIndicator');
  const statusText = document.getElementById('statusText');
  const workspaceList = document.getElementById('workspaceList');
  const sendButton = document.getElementById('sendToEmojiStudio');
  const clearButton = document.getElementById('clearData');
  const lastRefreshedDiv = document.getElementById('lastRefreshed');
  const lastRefreshedText = document.getElementById('lastRefreshedText');
  
  let capturedData = {};
  
  function formatTimeAgo(timestamp) {
    if (!timestamp) return 'Never synced';
    
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) return `${days} day${days === 1 ? '' : 's'} ago`;
    if (hours > 0) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
    if (minutes > 0) return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
    if (seconds > 30) return `${seconds} seconds ago`;
    return 'Just now';
  }
  
  async function updateUI() {
    const response = await chrome.runtime.sendMessage({ type: 'GET_CAPTURED_DATA' });
    capturedData = response.data || {};
    
    const workspaceCount = Object.keys(capturedData).length;
    
    // Get last sync time from storage
    const { lastSyncTime } = await chrome.storage.local.get('lastSyncTime');
    
    if (workspaceCount > 0) {
      statusIndicator.classList.add('active');
      statusText.textContent = `${workspaceCount} workspace${workspaceCount > 1 ? 's' : ''} connected`;
      sendButton.disabled = false;
      
      workspaceList.innerHTML = '';
      Object.entries(capturedData).forEach(([workspace, data]) => {
        const item = document.createElement('div');
        item.className = 'workspace-item';
        item.innerHTML = `
          <div>
            <div class="workspace-name">${workspace}.slack.com</div>
            <div class="workspace-status">Token: ${data.token ? '✓' : '✗'} | Cookie: ${data.cookie ? '✓' : '✗'}</div>
          </div>
        `;
        workspaceList.appendChild(item);
      });
      
      // Show last refreshed time
      lastRefreshedDiv.style.display = 'flex';
      lastRefreshedText.textContent = formatTimeAgo(lastSyncTime);
    } else {
      statusIndicator.classList.remove('active');
      statusText.textContent = 'No workspaces connected';
      sendButton.disabled = true;
      workspaceList.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📡</div><p class="empty-state-text">No workspaces detected yet</p></div>';
      lastRefreshedDiv.style.display = 'none';
    }
  }
  
  sendButton.addEventListener('click', async () => {
    try {
      const emojiStudioUrl = 'http://localhost:3001';
      
      const tabs = await chrome.tabs.query({ url: `${emojiStudioUrl}/*` });
      
      if (tabs.length > 0) {
        const dataToSend = Object.values(capturedData)[0];
        console.log('Sending data to existing tab:', dataToSend);
        
        // Navigate to dashboard if not already there
        const dashboardTab = tabs.find(tab => tab.url.includes('/dashboard'));
        if (dashboardTab) {
          await chrome.tabs.update(dashboardTab.id, { active: true });
          // Wait a bit for the tab to be active
          setTimeout(async () => {
            try {
              await chrome.tabs.sendMessage(dashboardTab.id, {
                type: 'EMOJI_STUDIO_DATA',
                data: dataToSend
              });
              console.log('Data sent to dashboard tab');
            } catch (err) {
              console.error('Error sending to dashboard tab:', err);
            }
          }, 500);
        } else {
          const tabId = tabs[0].id;
          
          // Store data in extension's storage before navigation
          console.log('Storing data in chrome.storage:', dataToSend);
          await chrome.storage.local.set({ 
            pendingExtensionData: dataToSend,
            lastSyncTime: Date.now()
          });
          console.log('Data stored, navigating to dashboard');
          
          // Now navigate to the dashboard
          await chrome.tabs.update(tabId, { 
            url: `${emojiStudioUrl}/dashboard?extension=true`,
            active: true 
          });
        }
        
        // Close popup after a short delay
        setTimeout(() => window.close(), 1000);
      } else {
        const dataToSend = Object.values(capturedData)[0];
        console.log('Creating new tab with data:', dataToSend);
        
        // Store data in extension's storage before creating tab
        console.log('Storing data in chrome.storage:', dataToSend);
        await chrome.storage.local.set({ 
          pendingExtensionData: dataToSend,
          lastSyncTime: Date.now()
        });
        console.log('Data stored, creating new tab');
        
        // Create new tab directly with the dashboard URL
        const newTab = await chrome.tabs.create({ 
          url: `${emojiStudioUrl}/dashboard?extension=true` 
        });
        
        // Close popup after a short delay
        setTimeout(() => window.close(), 1000);
      }
    } catch (error) {
      console.error('Error sending data:', error);
      alert('Failed to send data to Emoji Studio. Make sure the app is running.');
    }
  });
  
  clearButton.addEventListener('click', async () => {
    if (confirm('Are you sure you want to clear all captured Slack data?')) {
      await chrome.runtime.sendMessage({ type: 'CLEAR_DATA' });
      await chrome.storage.local.remove(['lastSyncTime']);
      await updateUI();
    }
  });
  
  await updateUI();
  
  // Update the refresh time every minute
  setInterval(() => {
    chrome.storage.local.get('lastSyncTime', ({ lastSyncTime }) => {
      if (lastSyncTime && lastRefreshedDiv.style.display === 'flex') {
        lastRefreshedText.textContent = formatTimeAgo(lastSyncTime);
      }
    });
  }, 60000); // Update every minute
});