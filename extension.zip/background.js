let capturedData = {};
let debugMode = true;
let pendingRequestData = new Map();

function log(...args) {
  if (debugMode) {
    console.log('[Emoji Studio Extension]', ...args);
  }
}

// Initialize the extension and set up alarms
chrome.runtime.onInstalled.addListener(() => {
  log('Extension installed/updated');
  
  // Set up alarm for auto-sync every 24 hours
  chrome.alarms.create('autoSync', {
    periodInMinutes: 24 * 60 // 24 hours
  });
  
  // Load existing data from storage
  chrome.storage.local.get('slackData', (result) => {
    if (result.slackData) {
      capturedData = result.slackData;
      log('Loaded existing data:', Object.keys(capturedData));
    }
  });
  
  // Also check immediately
  checkAndAutoSync();
});

// Also load data on startup (not just on install)
chrome.storage.local.get('slackData', (result) => {
  if (result.slackData) {
    capturedData = result.slackData;
    log('Loaded existing data on startup:', Object.keys(capturedData));
  }
});

// Handle alarm events
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'autoSync') {
    log('Auto-sync alarm triggered');
    checkAndAutoSync();
  }
});

// Function to perform auto-sync
async function checkAndAutoSync() {
  const { lastSyncTime } = await chrome.storage.local.get('lastSyncTime');
  const now = Date.now();
  const twentyFourHours = 24 * 60 * 60 * 1000;
  
  // Check if we have data and if it's been more than 24 hours
  if (Object.keys(capturedData).length > 0 && (!lastSyncTime || (now - lastSyncTime) > twentyFourHours)) {
    log('Auto-syncing data to Emoji Studio');
    
    try {
      // Find Emoji Studio tab or create one
      const emojiStudioUrl = 'http://localhost:3001';
      const tabs = await chrome.tabs.query({ url: `${emojiStudioUrl}/*` });
      
      const dataToSend = Object.values(capturedData)[0];
      
      if (tabs.length > 0) {
        // Use existing tab
        const tabId = tabs[0].id;
        await chrome.storage.local.set({ 
          pendingExtensionData: dataToSend,
          lastSyncTime: now
        });
        
        await chrome.tabs.update(tabId, { 
          url: `${emojiStudioUrl}/dashboard?extension=true`
        });
      } else {
        // Create new tab
        await chrome.storage.local.set({ 
          pendingExtensionData: dataToSend,
          lastSyncTime: now
        });
        
        await chrome.tabs.create({ 
          url: `${emojiStudioUrl}/dashboard?extension=true` 
        });
      }
      
      log('Auto-sync completed');
    } catch (error) {
      log('Auto-sync error:', error);
    }
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  log('Received message:', request.type);
  
  if (request.type === 'SLACK_DATA_CAPTURED') {
    const workspace = request.data.workspace;
    capturedData[workspace] = request.data;
    
    chrome.storage.local.set({ slackData: capturedData });
    
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#22c55e' });
    
    log('Data captured for workspace:', workspace);
    sendResponse({ success: true });
  } else if (request.type === 'GET_CAPTURED_DATA') {
    sendResponse({ data: capturedData });
  } else if (request.type === 'CLEAR_DATA') {
    capturedData = {};
    chrome.storage.local.remove('slackData');
    chrome.action.setBadgeText({ text: '' });
    sendResponse({ success: true });
  } else if (request.type === 'SLACK_AUTH_FAILED') {
    log('Authentication failed for workspace:', request.workspace);
    chrome.action.setBadgeText({ text: '✗' });
    chrome.action.setBadgeBackgroundColor({ color: '#ef4444' });
    sendResponse({ success: true });
  }
  
  return true; // Keep message channel open for async response
});

// Listen for all Slack API requests
chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    log('Request intercepted:', details.url);
    
    if (details.url.includes('/api/emoji.adminList') || 
        details.url.includes('/api/emoji.list') ||
        details.url.includes('/api/emoji.') ||
        details.url.includes('/api/client.')) {
      
      log('Emoji-related request found:', details.url);
      
      // Extract token from form data if present
      let formToken = null;
      if (details.requestBody && details.requestBody.formData && details.requestBody.formData.token) {
        formToken = details.requestBody.formData.token[0];
        log('Found token in form data:', formToken.substring(0, 20) + '...');
      }
      
      // Store the form token for this request
      if (formToken) {
        pendingRequestData.set(details.requestId, { formToken });
      }
      
      const tabId = details.tabId;
      if (tabId > 0) {
        chrome.tabs.sendMessage(tabId, {
          type: 'INTERCEPT_REQUEST',
          url: details.url,
          requestId: details.requestId,
          formToken: formToken
        }).catch(err => log('Error sending message to content script:', err));
      }
    }
  },
  { urls: ["https://*.slack.com/api/*"] },
  ["requestBody"]
);

chrome.webRequest.onSendHeaders.addListener(
  function(details) {
    if (details.url.includes('/api/emoji.adminList') || 
        details.url.includes('/api/emoji.list') ||
        details.url.includes('/api/emoji.') ||
        details.url.includes('/api/client.')) {
      
      log('Headers captured for:', details.url);
      
      const headers = {};
      details.requestHeaders.forEach(header => {
        headers[header.name.toLowerCase()] = header.value;
      });
      
      // Get stored form data for this request
      const requestData = pendingRequestData.get(details.requestId);
      const formToken = requestData ? requestData.formToken : null;
      
      // Log important headers
      if (headers.cookie) {
        log('Cookie found:', headers.cookie.substring(0, 50) + '...');
      }
      if (headers.authorization) {
        log('Authorization found:', headers.authorization.substring(0, 30) + '...');
      }
      if (formToken) {
        log('Form token available:', formToken.substring(0, 20) + '...');
      }
      
      const tabId = details.tabId;
      if (tabId > 0) {
        chrome.tabs.sendMessage(tabId, {
          type: 'CAPTURE_HEADERS',
          url: details.url,
          headers: headers,
          requestId: details.requestId,
          formToken: formToken
        }).catch(err => log('Error sending headers to content script:', err));
      }
      
      // Clean up stored data
      pendingRequestData.delete(details.requestId);
    }
  },
  { urls: ["https://*.slack.com/api/*"] },
  ["requestHeaders", "extraHeaders"]  // Added extraHeaders for more complete header access
);

chrome.runtime.onInstalled.addListener(() => {
  log('Extension installed/updated');
  chrome.storage.local.get('slackData', (result) => {
    if (result.slackData) {
      capturedData = result.slackData;
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#4CAF50' });
      log('Restored data for workspaces:', Object.keys(capturedData));
    }
  });
});

// Clean up old pending request data periodically
setInterval(() => {
  const now = Date.now();
  for (const [id, data] of pendingRequestData.entries()) {
    if (now - (data.timestamp || now) > 30000) {
      pendingRequestData.delete(id);
    }
  }
}, 60000);

// Log when extension starts
log('Background script loaded');