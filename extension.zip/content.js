const pendingRequests = new Map();
let debugMode = true;
let lastCapturedWorkspace = null;
let lastCaptureTime = 0;

function log(...args) {
  if (debugMode) {
    console.log('[Emoji Studio Content]', ...args);
  }
}

log('Content script loaded on:', window.location.href);

function extractWorkspace() {
  const match = window.location.hostname.match(/^([^.]+)\.slack\.com$/);
  return match ? match[1] : null;
}

// Check if user is on a Slack login page
function checkIfLoggedIn() {
  const workspace = extractWorkspace();
  if (!workspace) return;
  
  // Check for common login page indicators
  const isLoginPage = 
    window.location.pathname.includes('/signin') ||
    window.location.pathname.includes('/login') ||
    window.location.pathname === '/' && document.querySelector('input[type="password"]') ||
    document.querySelector('.signin_form') ||
    document.querySelector('[data-qa="signin_domain_input"]');
    
  if (isLoginPage) {
    log('User is on login page - not authenticated');
    chrome.runtime.sendMessage({
      type: 'SLACK_AUTH_FAILED',
      workspace: workspace
    });
  }
}

// Check authentication status on page load
setTimeout(checkIfLoggedIn, 1000);

function extractDataFromHeaders(headers) {
  const data = {
    workspace: extractWorkspace(),
    token: null,
    cookie: null,
    teamId: null,
    xId: null
  };
  
  // Try different token patterns
  if (headers.authorization) {
    const tokenMatch = headers.authorization.match(/Bearer\s+(xox[a-zA-Z]-[\w-]+)/);
    if (tokenMatch) {
      data.token = tokenMatch[1];
    }
  }
  
  // Look for token in cookie as well
  if (headers.cookie) {
    // Split cookies and find the Slack 'd' cookie
    const cookies = headers.cookie.split(/;\s*/);
    for (const cookie of cookies) {
      const [name, value] = cookie.split('=');
      
      // The Slack 'd' cookie contains the authentication token
      if (name === 'd' && value && value.startsWith('xox')) {
        data.cookie = `d=${value}`;
        // Also use this as token if we don't have one
        if (!data.token) {
          data.token = value;
        }
      }
      
      // Extract team ID
      if (name === 'team_id' && value) {
        data.teamId = value;
      }
    }
    
    // If we still don't have a proper d cookie, log all cookies for debugging
    if (!data.cookie || !data.cookie.includes('xox')) {
      log('Warning: No valid Slack d cookie found. All cookies:', headers.cookie.substring(0, 200) + '...');
    }
  }
  
  // Extract X-Slack headers
  Object.keys(headers).forEach(key => {
    if (key.startsWith('x-slack-')) {
      log(`Found Slack header: ${key}:`, headers[key]);
      if (key === 'x-slack-client-request-id') {
        data.xId = headers[key];
      }
    }
  });
  
  return data;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  log('Received message:', request.type);
  
  if (request.type === 'INTERCEPT_REQUEST') {
    pendingRequests.set(request.requestId, {
      url: request.url,
      timestamp: Date.now(),
      formToken: request.formToken
    });
    log('Intercepted request:', request.url);
    if (request.formToken) {
      log('Form token present:', request.formToken.substring(0, 20) + '...');
    }
  } else if (request.type === 'CAPTURE_HEADERS') {
    const pendingRequest = pendingRequests.get(request.requestId);
    if (pendingRequest) {
      log('Processing headers for:', request.url);
      const data = extractDataFromHeaders(request.headers);
      
      // Use form token if available and no token found in headers
      if (request.formToken) {
        log('Using form token:', request.formToken.substring(0, 20) + '...');
        data.token = request.formToken;
      }
      
      log('Extracted data:', data);
      
      if (data.token && data.workspace) {
        // Check if we've already captured this workspace recently (within 5 seconds)
        const now = Date.now();
        const isDuplicate = lastCapturedWorkspace === data.workspace && 
                           (now - lastCaptureTime) < 5000;
        
        if (!isDuplicate) {
          lastCapturedWorkspace = data.workspace;
          lastCaptureTime = now;
          
          chrome.runtime.sendMessage({
            type: 'SLACK_DATA_CAPTURED',
            data: data
          }).then(() => {
            showNotification('Slack data captured successfully!');
          }).catch(err => {
            log('Error sending data to background:', err);
          });
        } else {
          log('Duplicate capture prevented for workspace:', data.workspace);
          // Still send to background but don't show notification
          chrome.runtime.sendMessage({
            type: 'SLACK_DATA_CAPTURED',
            data: data
          });
        }
      } else if (data.workspace && !data.token) {
        log('Authentication failed - no token found');
        chrome.runtime.sendMessage({
          type: 'SLACK_AUTH_FAILED',
          workspace: data.workspace
        });
      } else {
        log('Missing required data. Token:', !!data.token, 'Workspace:', !!data.workspace);
      }
      
      pendingRequests.delete(request.requestId);
    }
  }
  
  return true; // Keep message channel open
});

function showNotification(message) {
  // Check if notification already exists
  const existingNotification = document.querySelector('.emoji-studio-notification');
  if (existingNotification) {
    existingNotification.remove();
  }
  
  const notification = document.createElement('div');
  notification.className = 'emoji-studio-notification';
  notification.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right: 8px;">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
    ${message}
  `;
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: #22c55e;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(34, 197, 94, 0.25);
    z-index: 10000;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    font-size: 14px;
    font-weight: 500;
    display: flex;
    align-items: center;
    animation: slideIn 0.3s ease-out;
  `;
  
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from { transform: translateX(100%); opacity: 0; }
      to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
      from { transform: translateX(0); opacity: 1; }
      to { transform: translateX(100%); opacity: 0; }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease-out forwards';
    setTimeout(() => notification.remove(), 300);
  }, 2000); // Reduced from 3000ms to 2000ms
}

// Clean up old pending requests
setInterval(() => {
  const now = Date.now();
  for (const [id, request] of pendingRequests.entries()) {
    if (now - request.timestamp > 30000) {
      pendingRequests.delete(id);
    }
  }
}, 10000);